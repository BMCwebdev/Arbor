

	<?php
		
	/* ----------------------------------------------------------------------------------
		Author Name, Avatar, Description and Website Details
	---------------------------------------------------------------------------------- */		
	if ( have_posts() ) : the_post();
	if(get_query_var('author_name')) :
		$curauth = get_userdatabylogin(get_query_var('author_name'));
	else :
		$curauth = get_userdata(get_query_var('author'));
	endif;
	?>

	<!-- .......... About Author .......... -->	
			
	<div class="about_author">
		<h4 class="title_line"><span><?php _e('About the Author', 'swmtranslate'); ?></span></h4>	

		<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>">
			<?php echo get_avatar(get_the_author_meta('email'),$size='95',$default=get_template_directory_uri().'/images/thumbs/blog-author.jpg' ); ?>
		</a>			

		<p><?php the_author_meta('description'); ?></p>	
					
		<?php if ($curauth->user_url) { ?>

			<p style="margin-top:10px;"><strong><?php _e('Website:', 'swmtranslate')?></strong> <a href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->user_url; ?></a></p>
	
		<?php } ?>
					
	</div>

	<div class="clear"></div>
	<div class="divider"></div>
		
	
	<?php endif; ?>		

	<ul class="clear">		
		
		<?php

		/* ----------------------------------------------------------------------------------
			Author Posts List
		---------------------------------------------------------------------------------- */	
		
		rewind_posts();
		
		if ( have_posts() ) : 
			while (have_posts()) : the_post(); ?>
							
				<article class="blog_post">
			<div class="pf_section"><?php swm_display_post_format(); ?></div>	

			<div class="blog_post_content">
				
				<?php swm_display_blog_date_section(); ?>

				<div class="blog_post_text">
					<?php swm_display_blog_title_section(); 
							
					/* Display Post Summery/Excerpt */					
					$swm_show_excerpt = of_get_option('swm_show_excerpt');
					$swm_excerpt_length = of_get_option('swm_excerpt_length');
					$format = get_post_format();								
					
					if ( $format != 'quote' && $format != 'aside' ) { 
					
						if($swm_show_excerpt) { ?>
							<p> <?php
							swm_the_excerpt($swm_excerpt_length); ?>
							</p> <?php																	
							
						} else {
							the_content();
						} 
					}

					if ( $format == 'quote'  ||  $format == 'aside') {
						get_template_part( 'includes/' . $format );	
					}
					?>					
				</div>

				
				<?php swm_display_category_comments_author(); ?>
				

			</div>

		</article>	

			<?php endwhile; else: ?>
			<p><?php _e('No posts by this author.', 'swmtranslate'); ?></p>

		<?php endif; ?>		
	</ul>
	
	<?php 
	
	/* ----------------------------------------------------------------------------------
		Pagination
	---------------------------------------------------------------------------------- */	
	
	 /* Display navigation to next/previous pages when applicable */ ?>
<?php if (  $wp_query->max_num_pages > 1 ) : ?>
			 <?php if(function_exists('swm_pagination')) { ?>
				 <?php swm_pagination(); ?>
			 <?php }else{ ?>
				<div id="nav-below" class="navigation">
					<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&laquo;</span> Older', 'templatesquare' ) ); ?></div>
					<div class="nav-next"><?php previous_posts_link( __( 'Newer <span class="meta-nav">&raquo;</span>', 'templatesquare' ) ); ?></div>
				</div><!-- #nav-below -->
			<?php }?>
<?php endif; ?>