<?php 
header("Content-type: text/css; charset: UTF-8");
require_once( '../../../../wp-load.php' );

$swm_paragraph_font = of_get_option('swm_paragraph_font');
$swm_page_title_font = of_get_option('swm_page_title_font');
$swm_h1_heading_font = of_get_option('swm_h1_heading_font');
$swm_h2_heading_font = of_get_option('swm_h2_heading_font');
$swm_h3_heading_font = of_get_option('swm_h3_heading_font');
$swm_h4_heading_font = of_get_option('swm_h4_heading_font');
$swm_h5_heading_font = of_get_option('swm_h5_heading_font');
$swm_h6_heading_font = of_get_option('swm_h6_heading_font'); 

$swm_pf_excerpt_font_size = of_get_option('swm_pf_excerpt_fontsize'); 
 
$swm_sidebar_h2_heading_font = of_get_option('swm_sidebar_h2_heading_font');

$swm_additional_footer_h4_heading_font = of_get_option('swm_additional_footer_h4_heading_font');
$swm_footer_h2_heading_font = of_get_option('swm_footer_h2_heading_font');
$swm_large_footer_text = of_get_option('swm_large_footer_text');
$swm_blog_post_title_font = of_get_option('swm_blog_post_title_font');
$swm_small_footer_font = of_get_option('swm_small_footer_font');

$swm_custom_css = of_get_option('swm_custom_css');

// ========== common elements ========== 

if ($swm_paragraph_font != "") { 
	echo 'body, a, #sidebar,#sidebar a,#sidebar ul li,#content a.pf_readmore_btn:hover,.reply a,#content .comment-text cite,#content .comment-text cite a,#content ul.ordered_list li span,ul.our_awards li sub,ul.our_awards li sub a,.services_icon_small h4 small,.services_icon_medium h4 small,.pricing_table ul li,.pricing_table ul li a,
.team_member h5 sub,#content .support_team p a,#content .testimonials_left h5 sub,.testimonials_left a,#content .blog_post h3 a:hover,.horizontal_menu,.horizontal_menu a,.horizontal_menu li a,.post_bottom_bg,.post_bottom_bg span a,blockquote div,#sidebar .testimonials_slider ul li .client_testimonials h5,#sidebar .testimonials_slider ul li .client_testimonials h5 sub,code,pre,.promotion_box p sub { color:'.$swm_paragraph_font['color'].'; }
'; 
}  //end if

// ========== headings and paragraph ========== 

if ($swm_paragraph_font != "") { 
	echo '#content p {font-size:'.$swm_paragraph_font['size'].';}
'; }

if ($swm_page_title_font != "") { 
	echo '.page-title h1 { color:'.$swm_page_title_font['color'].';font-size:'.$swm_page_title_font['size'].'; }
'; }

if ($swm_h1_heading_font != "") { 
	echo '#content h1,#content h1 a { color:'.$swm_h1_heading_font['color'].';font-size:'.$swm_h1_heading_font['size'].'; }
'; }

if ($swm_h2_heading_font != "") { 
	echo '#content h2,#content h2 a { color:'.$swm_h2_heading_font['color'].';font-size:'.$swm_h2_heading_font['size'].'; }
'; }

if ($swm_h3_heading_font != "") { 
	echo '#content h3,#content h3 a { color:'.$swm_h3_heading_font['color'].';font-size:'.$swm_h3_heading_font['size'].'; }
'; }

if ($swm_h4_heading_font != "") { 
	echo '#content h4,#content h4 a,.list_slider_title { color:'.$swm_h4_heading_font['color'].';font-size:'.$swm_h4_heading_font['size'].'; }
'; }

if ($swm_h5_heading_font != "") { 
	echo '#content h5,#content h5 a { color:'.$swm_h5_heading_font['color'].';font-size:'.$swm_h5_heading_font['size'].'; }
'; }

if ($swm_h6_heading_font != "") { 
	echo '#content h6,#content h6 a { color:'.$swm_h6_heading_font['color'].';font-size:'.$swm_h6_heading_font['size'].'; }
'; }

if ($swm_sidebar_h2_heading_font != "") { 
	echo '#content #sidebar h2, #content #sidebar h3,#content #sidebar .sidebar-box h3,#sidebar h3 a.rsswidget { color:'.$swm_sidebar_h2_heading_font['color'].';font-size:'.$swm_sidebar_h2_heading_font['size'].'; }
'; }

if ($swm_additional_footer_h4_heading_font != "") { 
	echo '#additional-footer h2,#additional-footer h3,#additional-footer h4,#additional-footer h5,#additional-footer h6 { color:'.$swm_additional_footer_h4_heading_font['color'].';font-size:'.$swm_additional_footer_h4_heading_font['size'].'; }
'; }

if ($swm_footer_h2_heading_font != "") { 
	echo '#footer h1, #footer h2, #footer h3, #footer h4, #footer h5, #footer h6,#footer .widget h3 { color:'.$swm_footer_h2_heading_font['color'].';font-size:'.$swm_footer_h2_heading_font['size'].'; }
'; }

if ($swm_large_footer_text != "") { 
	echo '#footer ul li,.large-footer ul li a,.small-footer p,#footer .tagcloud a,#footer p,#footer a,#footer .my_toggle .my_toggle_title,#footer .my_tabs ul.tab-nav li a,#footer .testimonials_slider ul li .client_testimonials h5 sub,#footer select { color:'.$swm_large_footer_text['color'].';font-size:'.$swm_large_footer_text['size'].'; }
'; }
  
if ($swm_blog_post_title_font != "") { 
	echo '#content .post-title h3,#content .post-title h3 a { color:'.$swm_blog_post_title_font['color'].';font-size:'.$swm_blog_post_title_font['size'].'; }
'; }
  
if ($swm_small_footer_font != "") { 
	echo '.small-footer,.small-footer p,.small-footer p a { color:'.$swm_small_footer_font['color'].';font-size:'.$swm_small_footer_font['size'].'; }
'; } 

// ========== skin color ========== 

$swm_skin_color = of_get_option('swm_skin_color');

if ($swm_skin_color != "") { 

echo '
#sidebar ul li:hover>a,#sidebar ul li.current-cat a,#sidebar ul li.current-cat,#sidebar ul li.current_page_item a,#sidebar ul li.current-menu-item a,#sidebar ul li.current-cat a small,#sidebar ul li:hover a small,.skin_color,.skin_color a,.html #content ul.tabs li.tab-active a,.post_bottom_bg span.post_button a,#content .pf_box h3 a:hover,#content .flexslider .slides > li .rp_details h3 a:hover,.caption.med_white,.home_readmore a,#content .comment-text cite a:hover,#content .blog_post h3 a:hover,#content .services_icon_small:hover h4,#content .services_icon_medium:hover h4,#content .services_icon_large:hover h4,#content .home_services2:hover h4,#content .rc_posts h4 a:hover,#content .rc_posts ul li:hover h4 a,ul.our_awards li sub a:hover, #content ul.search-list a:hover,#footer ul li a:hover,.small-footer a:hover,
#footer ul > li.current-cat > a,#footer ul > li.current-cat,#footer ul > li.current_page_item > a,#footer ul > li.current-menu-item > a,#footer ul li a.latest-news-read-more,#content #sidebar ul li a.latest-news-read-more,#content .box-testimonials a.clientWebsite,#footer .box-testimonials a.clientWebsite,#footer #contact-form-widget p.formButton input,#content .rp_content a.read-more,#content blockquote p,#content  p a.pf_readmore_btn,.commendt_author a,a.comment-reply-link,#respond h3 small a#cancel-comment-reply-link,.toggle_icon span.ui-state-active,.toggle_box span.ui-state-active,.fcb_content a,.sti-icon,blockquote a  { color:'.$swm_skin_color.';  }
';

// ========== background ========== 

echo '.blog_post_comments,.blog_post_comments2 { background:'.$swm_skin_color.' url(../images/backgrounds/blog_comments_bg.png) no-repeat 0 bottom;}
'; 

echo '.ei-slider-thumbs li a:hover,.ei-slider-thumbs li.ei-slider-element a { background:'.$swm_skin_color.' url(../images/backgrounds/dot_bg3_hover.png) no-repeat 0 0; }
';

echo '
.page-title { background:'.$swm_skin_color.' url(../images/backgrounds/pattern2.png); }
';

echo '
#header_slider, #header_image { background:transparent url(../images/backgrounds/slider_background.png) no-repeat center top; }
';

echo '
#header_video { background:'.$swm_skin_color.' url(../images/backgrounds/slider_background2.png) no-repeat center bottom; }
';

echo '
.post_format_icon,.pf_gallery_nav a.next:hover,.flex-direction-nav a:hover,.pf_gallery_nav a.prev:hover,.jp-play-bar,.jp-volume-bar-value,.tm_hover,.bx-wrapper .bx-prev:hover,#footer .bx-wrapper .bx-prev:hover,.bx-wrapper .bx-next:hover,#footer .bx-wrapper .bx-next:hover,.footer_top_border,.pf_details3,.swm_list_slider .flex-direction-nav .flex-prev:hover,.swm_list_slider .flex-direction-nav .flex-next:hover,.flexslider_basic div.flex-caption h3,.ei-title h2  { background-color:'.$swm_skin_color.'; }
';

echo '.horizontal_menu li a.current,#content .paginate-com span.current,.horizontal_menu li a.active, .horizontal_menu li.current-menu-item a,.tm_social_media,#content .tm_style2 .tm_social_media,.p_bar_skin_color .p_bar_bg { background:'.$swm_skin_color.'; }
';

echo '
.fcb_style1 { background:'.$swm_skin_color.' url(../images/backgrounds/box_title_bg1.png) repeat-x 0 0; }
';

echo '
.zoom-icon  { background:'.$swm_skin_color.' url(../images/icons/icon_zoom2.png) no-repeat 50% 50%;}
';

echo '
.play-icon  { background:'.$swm_skin_color.' url(../images/icons/icon_play2.png) no-repeat 50% 50%;}
';

echo '
.link-icon   { background:'.$swm_skin_color.' url(../images/icons/icon_link2.png) no-repeat 50% 50%;}
';

// ========== border ========== 

echo '
.pf_gallery_pagination a:hover,.flex-control-nav li a.flex-active,.flex-control-nav li a:hover,#header_slider_fullwidth,.portfolio .pf_box:hover a img,.promotion_box:hover,.horizontal_menu li a.current,#content .paginate-com span.current,.horizontal_menu li a.active, .horizontal_menu li.current-menu-item a,.blog_post_date,.blog_post_date2,.tm_style2 .tm_box_content,#content .pf_box:hover .pf_details1,.flexslider .slides > li:hover .rp_details,
#content .recent_posts_list1 ul li,.top_bar_content #s:focus,.promotion_box,.blog_post_content:hover { border-color:'.$swm_skin_color.'; }
';

echo '.promotion_box:after { border-left: 4px solid '.$swm_skin_color.' !important; }
';

echo '.tm_box_content { border-top-color:'.$swm_skin_color.'; }
';

echo '.tm_style1:hover .tm_box_content { border-bottom-color:'.$swm_skin_color.'; }
';

echo '.top-menu>ul.sf-menu>li.active>a,.top-menu ul.sf-menu>li:hover>a,.top-menu>ul.sf-menu>li.current_page_item>a,.top-menu>ul.sf-menu>li.current-menu-item>a, .top-menu>ul.sf-menu>li.current-menu-parent>a, .top-menu>ul.sf-menu>li.current-category-ancestor>a,.top-menu>ul.sf-menu>li.current-post-ancestor>a,.top-menu>ul.sf-menu>li.current-page-ancestor>a,.top-menu>ul.sf-menu>li.current-menu-ancestor>a { border-top: 3px solid '.$swm_skin_color.'; padding-top: 0;}
';
echo '.top-menu>ul.sf-menu>li.active>a:after,.top-menu ul.sf-menu>li:hover>a:after,.top-menu>ul.sf-menu>li.current_page_item>a:after,.top-menu>ul.sf-menu>li.current-menu-item>a:after, .top-menu>ul.sf-menu>li.current-menu-parent>a:after, .top-menu>ul.sf-menu>li.current-category-ancestor>a:after,.top-menu>ul.sf-menu>li.current-post-ancestor>a:after,.top-menu>ul.sf-menu>li.current-page-ancestor>a:after,.top-menu>ul.sf-menu>li.current-menu-ancestor>a:after { border-top: 3px solid '.$swm_skin_color.' !important; }
';

} // << end if skin_color

// ========== skin button ========== 

$swm_skin_button_top = of_get_option('swm_skin_button_top');
$swm_skin_button_bottom = of_get_option('swm_skin_button_bottom');
$swm_skin_button_top_mouseover = of_get_option('swm_skin_button_top_mouseover');
$swm_skin_button_bottom_mouseover = of_get_option('swm_skin_button_bottom_mouseover');

if ($swm_skin_button_top != "" && $swm_skin_button_bottom != "") { 

echo '
.button.skin_color  { border-color: '.$swm_skin_button_bottom.'; background: '.$swm_skin_button_top.'; background: linear-gradient(top, '.$swm_skin_button_top.' 0%, '.$swm_skin_button_bottom.' 100%); background: -moz-linear-gradient(top, '.$swm_skin_button_top.' 0%, '.$swm_skin_button_bottom.' 100%); background: -webkit-gradient(linear, 0 0, 0 100%, from('.$swm_skin_button_top.'), to('.$swm_skin_button_bottom.')); 	background: -webkit-linear-gradient(top, '.$swm_skin_button_top.' 0%, '.$swm_skin_button_bottom.' 100%); }
';
} //end if

if ($swm_skin_button_top_mouseover != "" && $swm_skin_button_bottom_mouseover != "") { 

echo '
.button.skin_color:hover  { border-color: '.$swm_skin_button_bottom_mouseover.'; background: '.$swm_skin_button_top_mouseover.'; background: linear-gradient(top, '.$swm_skin_button_top_mouseover.' 0%, '.$swm_skin_button_bottom_mouseover.' 100%); background: -moz-linear-gradient(top, '.$swm_skin_button_top_mouseover.' 0%, '.$swm_skin_button_bottom_mouseover.' 100%); background: -webkit-gradient(linear, 0 0, 0 100%, from('.$swm_skin_button_top_mouseover.'), to('.$swm_skin_button_bottom_mouseover.')); 	background: -webkit-linear-gradient(top, '.$swm_skin_button_top_mouseover.' 0%, '.$swm_skin_button_bottom_mouseover.' 100%); }
';
} //end if

// ========== Google font ========== 

$swm_google_font_name = of_get_option('swm_google_font_name');
$swm_google_font_weight = of_get_option('swm_google_font_weight');

echo '
h1, h2, h3, h4, h5, h6,.pf_quote, .post_bottom_bg span.post_button a,.reply a,.top-menu>ul>li>a,.call_section,.recent_posts_list1_date,.fcb_title,.comment_author,#content .comment-text cite,#content .pf_box h3,.list_slider_title,.blog_post_date_comments,.blog_post_date_comments2,.caption.big_teal,ul.our_awards li,blockquote,.home_readmore,#content .promotion_box p,#content .steps_with_circle ol li span,.tbl-heading,.button.medium,.button.large,.button.xlarge { font-family: "'.$swm_google_font_name.'", arial, verdana, tahoma; font-weight: '.$swm_google_font_weight.';}
';

echo '.pf_quote { font-weight:normal; } #content .pf_details h3 {font-family:arial,tahoma} #content .promotion_box p sub {font-weight:normal;}
';

echo '.small-footer .tm_social_media { background:none;}
';

//styling

$swm_layout_style = of_get_option('swm_layout_style');
$swm_body_bg_image1 = of_get_option('swm_body_bg_image1');
$swm_bg_image_position1 = of_get_option('swm_bg_image_position1');
$swm_background_rep1 = of_get_option('swm_background_rep1');
$swm_background_col1 = of_get_option('swm_background_col1');

if ($swm_layout_style == 'fixed') {

echo '#body_container { width:1000px; margin:0 auto;  }
';

}else {

echo '#body_container { width:auto; margin:0 auto;  }
';	

} //end else

echo 'body { background:'.$swm_background_col1.' url('.$swm_body_bg_image1.') '.$swm_background_rep1.' '.$swm_bg_image_position1.'   } 
';

// ========== page title borders ========== 

$swm_headings_dot_border = of_get_option('swm_headings_dot_border');
$swm_page_title_dot_border = of_get_option('swm_page_title_dot_border');

if ($swm_headings_dot_border){
echo  '#content h1.title_line,#content h2.title_line,#content h3.title_line,#content h4.title_line,#content h5.title_line,#content h6.title_line,h3#reply-title,.list_slider_title { background: url(../images/backgrounds/dot_bg.png) repeat-x left 8px; }
';
echo '#content h1.title_line span,#content h2.title_line span,#content h3.title_line span,#content h4.title_line span,#content h5.title_line span,#content h6.title_line span,h3#reply-title span,.list_slider_title span { background:#fff; padding-right: 10px; }
';
echo '#footer h3 {background: url(../images/backgrounds/footer_title_bg.png) repeat-x left 8px;}
';	
echo '#footer h3 span { background:#1e1e1e; padding-right: 10px;}
';
} //end if

if ($swm_page_title_dot_border){
echo '#title_bar h1 { background:transparent url(../images/backgrounds/h1_dot_bg.png) 0 0;}
';
} //end if

// ========== custom css ========== 

if ($swm_custom_css != '') { 
	echo $swm_custom_css; 
}
 
?>