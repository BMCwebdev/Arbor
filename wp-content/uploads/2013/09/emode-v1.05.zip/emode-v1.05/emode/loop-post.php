	<?php		
	
	$exclude_cat = explode(',',of_get_option('swm_blog_exclude_categories'));	
	$items_per_page = of_get_option('swm_blog_posts_per_page');
	
	$args = array(
		'category__not_in' => $exclude_cat,
		'order'	=> 'desc',
		'orderby'	=> 'date',
		'posts_per_page' => $items_per_page,
		'paged' => get_query_var( 'paged' )
	);
	
	$blog_query = new WP_Query($args); 
	
	while ($blog_query->have_posts()) : $blog_query->the_post(); ?>	
	
		
		<article class="blog_post">
			<div class="pf_section"><?php swm_display_post_format(); ?></div>	

			<div class="blog_post_content">
				
				<?php swm_display_blog_date_section(); ?>

				<div class="blog_post_text">
					<?php swm_display_blog_title_section(); 
							
					/* Display Post Summery/Excerpt */					
					$swm_show_excerpt = of_get_option('swm_show_excerpt');
					$swm_excerpt_length = of_get_option('swm_excerpt_length');
					$format = get_post_format();								
					
					if ( $format != 'quote' && $format != 'aside' ) { 
					
						if($swm_show_excerpt) { ?>
							<p> <?php
							swm_the_excerpt($swm_excerpt_length); ?>
							</p> <?php																	
							
						} else {
							the_content();
						} 
					}

					if ( $format == 'quote'  ||  $format == 'aside') {
						get_template_part( 'includes/' . $format );	
					}
					?>					
				</div>

				
				<?php swm_display_category_comments_author(); ?>
				

			</div>

		</article>	
				
<?php endwhile; ?>	
		
	<?php swm_pagination($blog_query->max_num_pages);	?>