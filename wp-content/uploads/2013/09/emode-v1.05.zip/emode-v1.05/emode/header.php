<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<!-- title -->
<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
<?php 
wp_head();
?>
</head>
<body <?php body_class(); ?>>
<?php 
$swm_inner_page_header 			= of_get_option('swm_inner_page_header');
$swm_logo_right_content 		= of_get_option('swm_logo_right_content'); 
$swm_layout_style 				= of_get_option('swm_layout_style');

if ($swm_layout_style == 'fixed') {
	$header_id = 'header1';
} else {
	$header_id = 'header2';
}
?>

<div id="body_container">		

	<div id="<?php echo $header_id; ?>">

<!-- ......................[ Logo ]...................... -->	

	<div id="logo_bar">
		<div class="logosection">
			<a href="<?php echo home_url(); ?>">
				<?php 


				$logo_img = (of_get_option('swm_layout_color') == 'dark') ? 'logo2.png' : 'logo.png';

				$logo = (of_get_option('swm_logo') <> '') ? esc_attr(of_get_option('swm_logo')) : get_template_directory_uri().'/framework/images/' . $logo_img; ?>
				<img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" />
			</a>
		</div>
		<div class="call_section"><?php echo $swm_logo_right_content; ?></div>
		<div class="clear"></div>
	</div>

<!-- ......................[ End Logo ]...................... -->
		<div id="top_bar">
			<div class="top_bar_content">

<!-- ......................[ Top Menu ]...................... -->
				<div class="top-menu">
					<?php swm_display_topmenu(); ?>
				</div>		
<!-- ......................[ End Top Menu ]...................... -->

				<?php swm_display_searchbox(); ?>
			</div>
		</div> <!-- #top_bar -->

<!-- Top Bar End -->
	<div class="clear"></div>
<!-- ......................[ End Top Bar ]...................... -->			
	
</div> <!-- #header -->

<?php 

if (is_page_template('template-home-revolution-slider.php')) {

$swm_rev_slider_display_type	= get_post_meta(get_the_id(), 'swm_rev_slider_display_type', true);
$swm_rev_slider_shortcode 		= get_post_meta(get_the_id(), 'swm_rev_slider_shortcode', true);

}

if ( is_page_template('template-home-revolution-slider.php') && $swm_rev_slider_display_type == 'rev_fullwidth' ) { 

	echo do_shortcode( $swm_rev_slider_shortcode );

} else {
?>

<!-- ......................[ Transparent Section ]...................... -->	

<div id="transparent_section">
	<div class="transparent_shadow">
		<div class="transparent_section_wrap">			

			<?php
								
				
				if (is_page_template('template-home-slider.php')) { 
					get_template_part( 'includes/sliders' );				
				}
				
				if (is_page_template('template-home-image.php')) { 
					get_template_part( 'includes/home-image' );				
				}
				
				if (is_page_template('template-home-video.php')) { 
					get_template_part( 'includes/home-video' );				
				}
				
				if (is_page_template('template-home-revolution-slider.php')) { 
					echo do_shortcode( $swm_rev_slider_shortcode );			
				}

				if (!is_front_page() || $swm_inner_page_header == true){	
				
					if (!is_page_template('template-home-slider.php') && !is_page_template('template-home-image.php') && !is_page_template('template-home-video.php') && !is_page_template('template-home-revolution-slider.php')) { ?>				
						
						<div id="title_bar">
							<?php

							if (is_page())	{
								
								?><h1><?php the_title(); ?></h1><?php
							
							} else {
								
								?><h1><?php swm_get_inner_title(); ?></h1><?php
							}
							
							get_template_part( 'includes/breadcrumbs' );

							?>
							
						</div><!-- #title_bar -->						
					<?php 	

				 	}	 
				 }	

				 ?>

			<div class="clear"></div>
		</div>
	</div>	
</div> <!-- #transparent_section -->	

<?php 

} // if else template revolution fullwidth

?>

<!-- ......................[ End Transparent Section ]...................... -->

<!-- ......................[ Container ]...................... -->

	<div id="container">
		<div class="container_wrapper">	
			<div id="content">