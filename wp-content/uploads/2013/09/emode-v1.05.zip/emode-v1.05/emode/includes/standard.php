<?php

$postType = get_post_type();

if( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) && $postType != 'portfolio' ) { 
	
	$meta_standard = get_post_meta(get_the_ID(), 'swm_meta_standard', true);	
	$swm_featured_image = wp_get_attachment_url(get_post_thumbnail_id($id));

	$thumb = '<img src="'.swm_resize($swm_featured_image, 690, $meta_standard , true,'c', false).'" alt="" />';

	
	
	if ($swm_featured_image) {

		$output = '';		

		$output .= '<div class="post_format">';
		$output .= '<div class="fade-img2 zoom-icon">';
		$output .= '<a href="'.$swm_featured_image.'" data-rel="prettyPhoto" title="' . get_the_title() . '">';
		$output .= $thumb;
		$output .= '</a>';
		$output .= '</div>';	
		$output .= '</div>';

		echo $output;
	}
	
} ?>