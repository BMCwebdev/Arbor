<?php 

/* Exclude Slider Categories */
global $wpdb;

$terms = rwmb_meta( 'exclude_slider_categories', 'type=taxonomy&taxonomy=slider_category' );
$cats  = array();
$excluce_cats  = array();
$count = '';

//get slider category names
foreach ( $terms as $term ){
   $cats[] .= sprintf( $term->slug);
}		
// get slider category ids                 
foreach ( $cats  as $cat ) {                     
	$catid = $wpdb->get_var("SELECT term_id FROM $wpdb->terms WHERE slug='$cat'");
	$excluce_cats[] = $catid;
}

$args = array(
	'post_type' => 'slider',
	'orderby'=>'menu_order',
	'order'     => 'ASC',
	'posts_per_page' => -1,
	'paged' => $paged,
	'type' => get_query_var('type'),
	'tax_query' => array(
		array(
				'taxonomy' => 'slider_category',
				'field' => 'id',
				'terms' => $excluce_cats,
				'operator' => 'NOT IN',
			)
	) // end of tax_query
);

$query = new WP_Query( $args );	

$swm_page_slider_type 		= get_post_meta($post->ID, 'swm_page_slider_type', TRUE);	
$swm_slider_autoplay		= get_post_meta($post->ID, 'swm_slider_autoplay', TRUE);
$swm_slider_easing		= get_post_meta($post->ID, 'swm_slider_easing', TRUE);
$swm_elastic_animation_type	= get_post_meta($post->ID, 'swm_elastic_animation_type', TRUE);
$swm_flex_animation_type 	= get_post_meta($post->ID, 'swm_flex_animation_type', TRUE);
$swm_slideshow_interval		= get_post_meta($post->ID, 'swm_slideshow_interval', TRUE);
$swm_slideshow_speed 		= get_post_meta($post->ID, 'swm_slideshow_speed', TRUE);
$swm_elastic_title_easing 	= get_post_meta($post->ID, 'swm_elastic_title_easing', TRUE);
$swm_elastic_title_speed 	= get_post_meta($post->ID, 'swm_elastic_title_speed', TRUE);
$swm_flex_direction 		= get_post_meta($post->ID, 'swm_flex_direction', TRUE);
$swm_flex_animation_loop	= get_post_meta($post->ID, 'swm_flex_animation_loop', TRUE);
$swm_flex_smooth_height		= get_post_meta($post->ID, 'swm_flex_smooth_height', TRUE);
$swm_flex_bullet_nav 		= get_post_meta($post->ID, 'swm_flex_bullet_nav', TRUE);
$swm_flex_arrow_nav 		= get_post_meta($post->ID, 'swm_flex_arrow_nav', TRUE);
$swm_flex_thumbnail_arrow_nav= get_post_meta($post->ID, 'swm_flex_thumbnail_arrow_nav', TRUE);
$swm_flex_mouseover 		= get_post_meta($post->ID, 'swm_flex_mouseover', TRUE);
$swm_flex_slider_video 		= get_post_meta($post->ID, 'swm_flex_slider_video', TRUE);

// Elastic Slider ####################################################

if ($swm_page_slider_type == 'Elastic_Slider') {
?>
	<div id="elastic_slider">

		<div id="ei-slider" class="ei-slider">
            <ul class="ei-slider-large">

                <?php swm_slider_slides(); ?>

           </ul><!-- ei-slider-large -->
            <div class="clear"></div>
                 
                <ul class="ei-slider-thumbs" id="ei-center-align">                       
                    <li class="ei-slider-element"><a href="#">Current</a></li>
                   <?php
					while ($query->have_posts()) : $query->the_post();	

						$images = rwmb_meta( 'swm_slider_thumb_image', 'type=image' );									

					    if ( $images ) {
					  		foreach ( $images as $image ) {											   	
							   	$thumb = "{$image['url']}";
							    echo '<li><a href="#"></a><img src="'.swm_resize($thumb, 188,74,true,'c', false).'" alt="'.$title.'" /> </li>';
							}
					   	} else {
						    $title = get_the_title();
							$swm_thumb_image = wp_get_attachment_url(get_post_thumbnail_id($id));					
							$swm_slide_thumb_image = '<img src="'.swm_resize($swm_thumb_image, 188,74,true,'c', false).'" alt="'.$title.'" />';	
							?>
							<li>
							 	<a href="#"></a>
							 	<?php echo $swm_slide_thumb_image; ?>
	                        </li>
	                        <?php
                    	} //end else	
						$count++;  							
					endwhile; wp_reset_query(); 
						?>
               </ul><!-- ei-slider-thumbs -->
            </div><!-- ei-slider -->
		</div><!-- #elastic_slider -->	
		<div class="clear"></div>	

		 <script type="text/javascript">				 
			(function ($) {	$(document).ready(function(){
				jQuery("#ei-slider").eislideshow({
					easing				: '<?php echo $swm_slider_easing; ?>',
					autoplay			: <?php echo $swm_slider_autoplay; ?>,
					animation           : '<?php echo $swm_elastic_animation_type; ?>',
					slideshow_interval	: <?php echo $swm_slideshow_interval; ?>,
					speed				: <?php echo $swm_slideshow_speed; ?>,
					titleeasing			: '<?php echo $swm_elastic_title_easing; ?>',
					titlespeed			: <?php echo $swm_elastic_title_speed; ?>
				});
			}); })(jQuery);			
		 </script>
<?php
}

// Basic Slider ####################################################

if ($swm_page_slider_type == 'Basic_Slider') {
?>
	<div id="header_slider">

		<?php

		$swm_fix_bottom_space = '';		

		if (!$swm_flex_bullet_nav) {
			$swm_fix_bottom_space = 'nomargin';
		}
		?>
		
		<div class="flexslider flexslider_basic <?php echo $swm_fix_bottom_space; ?>" >
			<ul class="slides">
	                <?php swm_slider_slides(); ?>
	        </ul>
	        <div class="clear"></div>
		</div><!-- .flexslider_basic -->

		<script type="text/javascript">
		(function ($) {	$(document).ready(function(){
			jQuery(".flexslider_basic").flexslider({
				animation: '<?php echo $swm_flex_animation_type; ?>',
				pauseOnAction: true,
				slideshow: <?php echo $swm_slider_autoplay; ?>,
				slideshowSpeed: <?php echo $swm_slideshow_interval; ?>,
				easing: '<?php echo $swm_slider_easing; ?>',
				direction: '<?php echo $swm_flex_direction; ?>',
				useCSS: false,
				animationLoop: <?php echo $swm_flex_animation_loop; ?>,
				smoothHeight: <?php echo $swm_flex_smooth_height; ?>,
				animationSpeed: <?php echo $swm_slideshow_speed; ?>,
				controlNav: <?php echo $swm_flex_bullet_nav; ?>,
				directionNav: <?php echo $swm_flex_arrow_nav; ?>,
				pauseOnHover: <?php echo $swm_flex_mouseover; ?>,
				start: function(slider){
					$('body').removeClass('loading');
				}
			});
		}); })(jQuery);
		</script>

	</div> <!-- #header_slider -->	
	<div class="clear"></div>
<?php
}

// Thumb Slider ####################################################

if ($swm_page_slider_type == 'Thumbnail_Slider') {
?>
	<div id="header_slider">
		<div class="flexslider flexslider_basic" >
			<ul class="slides">
	                 <?php swm_slider_slides(); ?>
	        </ul>
	        <div class="clear"></div>
		</div><!-- .flexslider_basic -->

		<div id="thumbnail_slider">
	        <div class="flexslider flex_thumbnails">
	          <ul class="slides">
	            <?php   					
					while ($query->have_posts()) : $query->the_post();	

						$images = rwmb_meta( 'swm_slider_thumb_image', 'type=image' );									

					    if ( $images ) {
					  		foreach ( $images as $image ) {											   	
							   	$thumb = "{$image['url']}";
							    echo '<li><div class="active_slide_layer"></div><img src="'.swm_resize($thumb, 147,71,true,'c', false).'" alt="'.$title.'" /> </li>';
							}
					   	} else {
						    $title = get_the_title();
							$swm_thumb_image = wp_get_attachment_url(get_post_thumbnail_id($id));					
							$swm_slide_thumb_image = '<img src="'.swm_resize($swm_thumb_image, 147,71,true,'c', false).'" alt="'.$title.'" />';	
							?>
							<li>
							 	<div class="active_slide_layer"></div>
							 	<?php echo $swm_slide_thumb_image; ?>
	                        </li>
	                        <?php
                    	} //end else	
						$count++;  							
					endwhile; wp_reset_query(); 
					?>
	          </ul>

	        </div>
	    </div> <!-- #thumbnail slider -->	

	    <script type="text/javascript">
		(function ($) {	$(document).ready(function(){	
			jQuery('.flex_thumbnails').flexslider({
				animation: "slide",
				controlNav: false,
				directionNav: <?php echo $swm_flex_thumbnail_arrow_nav; ?>,
				animationLoop: true,
				slideshow: false,
				itemWidth: 147,
				itemMargin: 3,
				asNavFor: '.flexslider_basic',
				start: function(slider){
					jQuery('body').removeClass('loading');
				}
			});
			jQuery(".flexslider_basic").flexslider({
				animation: '<?php echo $swm_flex_animation_type; ?>',
				pauseOnAction: true,
				controlNav: false,
				slideshow: <?php echo $swm_slider_autoplay; ?>,
				slideshowSpeed: <?php echo $swm_slideshow_interval; ?>,
				easing: '<?php echo $swm_slider_easing; ?>',
				direction: '<?php echo $swm_flex_direction; ?>',
				useCSS: false,
				animationLoop: <?php echo $swm_flex_animation_loop; ?>,
				smoothHeight: <?php echo $swm_flex_smooth_height; ?>,
				animationSpeed: <?php echo $swm_slideshow_speed; ?>,
				directionNav: <?php echo $swm_flex_arrow_nav; ?>,
				pauseOnHover: <?php echo $swm_flex_mouseover; ?>,
				sync: ".flex_thumbnails",
				start: function(slider){
				jQuery('body').removeClass('loading');
				}
			});
		}); })(jQuery);
		</script>

	</div> <!-- #header_slider -->	
	<div class="clear"></div>
<?php
}

// Icon Slider ####################################################

if ($swm_page_slider_type == 'Icon_Slider') {
?>
	<div id="header_slider">
		<div class="flexslider flexslider_basic" >
			<ul class="slides">
	                <?php swm_slider_slides(); ?>
	        </ul>
	        <div class="clear"></div>
		</div><!-- .flexslider_basic -->

		<div id="icon_title_slider">
	        <div class="flexslider flex_icon_title">
	          	<ul class="slides">
	            <?php   					
					while ($query->have_posts()) : $query->the_post();
					    
						    $title = get_the_title();							
							$swm_slide_icon_names = get_post_meta($post->ID, 'swm_slide_icon_names', TRUE);
							$swm_slide_icon_subtitle = get_post_meta($post->ID, 'swm_slide_icon_subtitle', TRUE);
							?>
							<li>
								<div class="icon_layer"><i class="<?php echo $swm_slide_icon_names; ?>"></i></div><div class="title_layer"><h3><?php echo $title; ?></h3><p><?php echo $swm_slide_icon_subtitle; ?></p></div>		 	
	                        </li>
	                        <?php
                    	 //end else	
						$count++;  							
					endwhile; wp_reset_query(); 
						?>
	          </ul>

	        </div>
	    </div> <!-- #thumbnail slider -->	

	    <script type="text/javascript">
		(function ($) {	$(document).ready(function(){	
			jQuery('.flex_icon_title').flexslider({
		        animation: "slide",
		        controlNav: false,
		        directionNav: false, 
		        animationLoop: true,
		        slideshow: false,
		        itemWidth: 234,
		        itemMargin: 3,
		        asNavFor: '.flexslider_basic',
		        start: function(slider){
		            jQuery('body').removeClass('loading');
		          }
		      });

			jQuery(".flexslider_basic").flexslider({
				animation: '<?php echo $swm_flex_animation_type; ?>',
				pauseOnAction: true,
				controlNav: false,
				slideshow: <?php echo $swm_slider_autoplay; ?>,
				slideshowSpeed: <?php echo $swm_slideshow_interval; ?>,
				easing: '<?php echo $swm_slider_easing; ?>',
				direction: '<?php echo $swm_flex_direction; ?>',
				useCSS: false,
				animationLoop: <?php echo $swm_flex_animation_loop; ?>,
				smoothHeight: <?php echo $swm_flex_smooth_height; ?>,
				animationSpeed: <?php echo $swm_slideshow_speed; ?>,
				directionNav: <?php echo $swm_flex_arrow_nav; ?>,
				pauseOnHover: <?php echo $swm_flex_mouseover; ?>,
				sync: ".flex_icon_title",
				start: function(slider){
				jQuery('body').removeClass('loading');
				}
			});
		}); })(jQuery);

		</script>

	</div> <!-- #header_slider -->	
	<div class="clear"></div>
<?php
}

?>