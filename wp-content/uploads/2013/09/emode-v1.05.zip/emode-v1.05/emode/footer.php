<?php global $swm_theme_options; ?>		

				<div class="clear"></div>
			</div> <!-- #content end -->
		</div>
	</div> <!-- #container end -->	

<?php
$swm_on_off_large_footer 	= of_get_option('swm_on_off_large_footer');
$swm_on_off_small_footer 	= of_get_option('swm_on_off_small_footer');
$swm_layout_style 			= of_get_option('swm_layout_style');
$small_footer_margin = '';

if (!$swm_on_off_small_footer) {
	$footer_bg_style = 'style="background-color:#1e1e1e;"';
} else {
	$footer_bg_style = '';
	$small_footer_margin = 'style="padding-top:3px;"';
}

if (!is_404()) {	

	if ( $swm_on_off_large_footer ) {

	?>

	<!-- ...................... Large Footer ...................... -->

	<div id="footer">

		
		<div class="footer_top_border"></div>
		
		<div class="large-footer">			
				<?php  swm_display_footer_column(); ?>		
			<div class="clear"></div>
		</div>

	</div> <!-- #footer -->
	<!-- ...................... End Large Footer ...................... -->
	<?php

	}


} // end if !is_404

if ( $swm_on_off_small_footer ) {

?>
							
<!-- ...................... Small Footer ...................... -->

	
	<div class="small-footer">
		<div class="small-footer-content" <?php echo $small_footer_margin; ?>>		
	
			<?php 
				if (of_get_option('swm_footer_left_content')) { ?>
					<p class="left"><?php echo do_shortcode(stripslashes(of_get_option('swm_footer_left_content'))); ?></p>	
			<?php } else { ?>
					<p class="left"><?php _e('&copy; Copyright by Evolvelorem Inc. All Rights Reserved', 'swmtranslate') ?></p>	
			<?php } ?>	
			
			<div class="tm_social_media">
				<ul>
					<?php swm_display_social_media(); ?>
				</ul>
			</div>

			<div class="clear"></div>


		</div>
	</div>
<!-- ...................... End Small Footer ...................... -->	

<?php

}

?>
	<?php

	if ($swm_layout_style == 'fixed') {
		?> <div id="footer-bottom" <?php echo $footer_bg_style; ?>></div>
		<div id="footer-bottom-bg"></div>
<?php } ?>

</div> <!-- #body_container -->

<?php 
if ( is_singular() ) wp_print_scripts( 'comment-reply' );
wp_footer(); ?>

</body>
</html>	