<?php

function optionsframework_option_name() {
	// This gets the theme name from the stylesheet (lowercase and without spaces)
	$themename = get_theme_data(STYLESHEETPATH . '/style.css');
	$themename = $themename['Name'];
	$themename = preg_replace("/\W/", "", strtolower($themename) );
	
	$optionsframework_settings = get_option('optionsframework');
	$optionsframework_settings['id'] = $themename;
	update_option('optionsframework', $optionsframework_settings);
}

function optionsframework_options() {
	
	// Layout Body Color
	$layout_color = array(
						"light" => "Light Color - (white)",
						"dark" => "Dark Color - (dark grey)"
						);

	// Layout Display
	$layout_mode = array(
						"fixed" => "Fixed Layout",
						"wide" => "Wide Layout"
						);

	// Background Repeat
	$background_repeat = array(
						"repeat" => "Repeat",
						"no-repeat" => "No Repeat",
						"repeat-x" => "Repeat X",
						"repeat-y" => "Repeat Y",
						"fixed" => "Fixed"
						);

	// Background Position
	$background_position = array(
						"center" => "Center",
						"left" => "Left",
						"right" => "Right"
						);

	// Footer Column
	$footer_column = array(
						"one-column" => "1",
						"two-column" => "2",
						"three-column" => "3",
						"four-column" => "4",
						"five-column" => "5",
						"six-column" => "6"
						);

	// Video Type
	$embed_video_type = array(
						"vid-youtube" => __('YouTube', 'swmtranslate'),
						"vid-vimeo" => __('Vimeo', 'swmtranslate')						
						);	

	// Blog Sidebar
	$sidebar_position = array(
						"left-sidebar" => __('Left Sidebar', 'swmtranslate'),
						"right-sidebar" => __('Right Sidebar', 'swmtranslate')
						);
						
	// Portfolio Single Page
	$portfolio_single_options = array(
						"portfolio-with-right-sidebar" => __('Portfolio Single Page with Right Sidebar', 'swmtranslate'),
						"portfolio-with-left-sidebar" => __('Portfolio Single Page with Left Sidebar', 'swmtranslate'),
						"portfolio-with-fullwidth" => __('Portfolio Single Page with Full Width', 'swmtranslate')
						);					
	
	// Pull all the categories into an array
	$options_categories = array();  
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
    	$options_categories[$category->cat_ID] = $category->cat_name;
	}
	
	// Pull all the pages into an array
	$options_pages = array();  
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	$options_pages[''] = 'Select a page:';
	foreach ($options_pages_obj as $page) {
    	$options_pages[$page->ID] = $page->post_title;
	}
		
	// If using image radio buttons, define a directory path
	$skin_imagepath =  get_stylesheet_directory_uri() . '/framework/images/skins/';
		
	$shortname = 'swm';
	
	$swm_theme_options = array();
		
	/* General Options */

	$swm_theme_options[] = array( 
						"name" => __('General', 'swmtranslate'),
						"id" => $shortname."_general",
						"type" => "heading");
						
	$swm_theme_options[] = array( 
						"name" => __('General Settings', 'swmtranslate'),
						"id" => $shortname."sh1",
						"type" => "sub-heading");						
						
	$swm_theme_options[] = array( 
						"name" => __('Upload Logo', 'swmtranslate'),
						"desc" => __('Upload your company logo image. (recommended size : <strong>239 x 107</strong>).', 'swmtranslate'),						
						"id" => $shortname."_logo",						
						"type" => "upload");

	$swm_theme_options[] = array( 
						"name" => __('Upload Favicon', 'swmtranslate'),
						"desc" => __('Upload <strong>favicon.ico</strong> image in size <strong>16 x 16</strong>. You can generate favicon from www.favicon.cc', 'swmtranslate'),					
						"id" => $shortname."_favicon",
						"type" => "upload");
	
	$swm_theme_options[] = array( 
						"name" => __('Logo Right Area Content', 'swmtranslate'),
						"desc" => __('Add phone number or any other text).', 'swmtranslate'),						
						"id" => $shortname."_logo_right_content",
						"std" => "<span class='skin_color'>Call:</span> 888.765.4321",					
						"type" => "textarea");

	$swm_theme_options[] = array( 
						"name" => __('Display Search Bar', 'swmtranslate'),
						"desc" => __('Show/Hide header Search Box', 'swmtranslate'),						
						"id" => $shortname."_search_bar",
						"std" => "1",
						"type" => "checkbox");

	$swm_theme_options[] = array( 
						"name" => __('Display Breadcrumbs', 'swmtranslate'),
						"desc" => __('Show/Hide breadcrumbs', 'swmtranslate'),						
						"id" => $shortname."_breadcrumbs",
						"std" => "1",
						"type" => "checkbox");				
						
	$swm_theme_options[] = array( 
						"name" => __('Display Scroll To Top Arrow Icon', 'swmtranslate'),
						"desc" => __('Show/Hide bottom right <i>Go to Top arrow icon.</i>', 'swmtranslate'),						
						"id" => $shortname."_scroll_to_top",
						"std" => "1",
						"type" => "checkbox");

	$swm_theme_options[] = array( 
						"name" => __('Sidebar Position', 'swmtranslate'),
						"desc" => __('Select sidebar position for all inner pages and posts', 'swmtranslate'),
						"id" => $shortname."_blog_sidebar_position",
						"std" => "right-sidebar",
						"type" => "select",	
						"class" => "mini",
						"options" => $sidebar_position);

	$swm_theme_options[] = array( 
						"name" => __('Set Inner page Header in Home page', 'swmtranslate'),
						"desc" => __('Set ON to remove default home page large header and set inner page header ( like About Us, Testimonials etc. ) and then select inner page from Settings > Reading > Front page display > Front page drop dwon.', 'swmtranslate'),						
						"id" => $shortname."_inner_page_header",
						"std" => "0",
						"type" => "checkbox");	

	$swm_theme_options[] = array( 
						"name" => __('Google  Analytical Code', 'swmtranslate'),
						"desc" => __('Enter your google id (generally it looks like this: UA-XXXXX-X).', 'swmtranslate'),						
						"id" => $shortname."_google_analytical",
						"std" => "",
						"type" => "text");									
	
	/* Styling */
	
	$swm_theme_options[] = array( 
						"name" => __('Styling', 'swmtranslate'),
						"id" => $shortname."_styling",
						"type" => "heading");
						
	$swm_theme_options[] = array( 
						"name" => __('Layout Style and Body Background', 'swmtranslate'),
						"id" => $shortname."sh2_1",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Layout Body Color', 'swmtranslate'),
						"desc" => __('Select layout style - Fixed width or Wide', 'swmtranslate'),
						"id" => $shortname."_layout_color",
						"std" => "light",
						"type" => "select",	
						"class" => "mini",
						"options" => $layout_color);

	$swm_theme_options[] = array( 
						"name" => __('Layout Display', 'swmtranslate'),
						"desc" => __('Select layout style - Fixed width or Wide', 'swmtranslate'),
						"id" => $shortname."_layout_style",
						"std" => "fixed",
						"type" => "select",	
						"class" => "mini",
						"options" => $layout_mode);

	$swm_theme_options[] = array( 
						"name" => __('Background Image', 'swmtranslate'),
						"desc" => __('Upload background image to display in all pages (recommended size : <strong>1920 x 1280</strong>)', 'swmtranslate'),						
						"id" => $shortname."_body_bg_image1",						
						"type" => "upload");

	$swm_theme_options[] = array( 
						"name" => __('Background Image Position', 'swmtranslate'),
						"desc" => __('Select background position of body background', 'swmtranslate'),
						"id" => $shortname."_bg_image_position1",
						"std" => "center",
						"type" => "select",	
						"class" => "mini",
						"options" => $background_position);

	$swm_theme_options[] = array( 
						"name" => __('Background Image Repeat', 'swmtranslate'),
						"desc" => __('Select background display property', 'swmtranslate'),
						"id" => $shortname."_background_rep1",
						"std" => "fixed",
						"type" => "select",	
						"class" => "mini",
						"options" => $background_repeat);

	$swm_theme_options[] = array( 
						"name" => __('Background Color', 'swmtranslate'),
						"desc" => __('If you don\'t want to upload background image then add background color value', 'swmtranslate'),						
						"id" => $shortname."_background_col1",
						"std" => '#8f8f8f',
						"type" => "color");	



	$swm_theme_options[] = array( 
						"name" => __('Theme\'s Skin Settings', 'swmtranslate'),
						"id" => $shortname."sh2",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Skin Color', 'swmtranslate'),
						"desc" => __('( Default : #ee7e2c )', 'swmtranslate'),						
						"id" => $shortname."_skin_color",
						"std" => '#ee7e2c',
						"type" => "color");

	$swm_theme_options[] = array( 
						"name" => __('Skin Button Color', 'swmtranslate'),
						"id" => $shortname."skin_btn",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => '',
						"desc" => __('Enter skin color button top and bottom value to make it gradient (light to dark)', 'swmtranslate'),
						"id" => $shortname."_skin_button_info",
						"std" => "",				
						"class" => "social_intro_text",
						"type" => "info");

	$swm_theme_options[] = array( 
						"name" => __('Skin Button Top Color', 'swmtranslate'),
						"desc" => __('Select button top color ( e.g. #fa8936 )', 'swmtranslate'),						
						"id" => $shortname."_skin_button_top",
						"std" => '#fa8936',
						"type" => "color");

	$swm_theme_options[] = array( 
						"name" => __('Skin Button Bottom Color', 'swmtranslate'),
						"desc" => __('Select button bottom color ( e.g.#e87826 )', 'swmtranslate'),						
						"id" => $shortname."_skin_button_bottom",
						"std" => '#e87826',
						"type" => "color");	
	

	$swm_theme_options[] = array( 
						"name" => __('Skin Button Top Mouseover Color', 'swmtranslate'),
						"desc" => __('Select button top mouseover color ( e.g.#ee7e2c )', 'swmtranslate'),						
						"id" => $shortname."_skin_button_top_mouseover",
						"std" => '#ee7e2c',
						"type" => "color");

	$swm_theme_options[] = array( 
						"name" => __('Skin Button Bottom Mouseover Color', 'swmtranslate'),
						"desc" => __('Select button bottom mouseover color ( e.g.#df6e1c )', 'swmtranslate'),						
						"id" => $shortname."_skin_button_bottom_mouseover",
						"std" => '#df6e1c',
						"type" => "color");


	/* Fonts - Light Layout */
	
	$swm_theme_options[] = array( 
						"name" => __('Fonts', 'swmtranslate'),
						"id" => $shortname."_fonts",
						"type" => "heading");

	$swm_theme_options[] = array( 
						"name" => __('Google Font', 'swmtranslate'),
						"id" => $shortname."sh13",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Import Google Font', 'swmtranslate'),
						"desc" => __('Add google font url as per above example. (Go to http://www.google.com/webfonts > Choose any font and click on "Quick use" link at right side > 3rd section "Add this code to your website" > "Standard" tab > only copy url which starts ..http//... like above example in the box.)', 'swmtranslate'),						
						"id" => $shortname."_google_font_url",
						"std" => 'http://fonts.googleapis.com/css?family=Patua+One',						
						"type" => "textarea");

	$swm_theme_options[] = array( 
						"name" => __('Font Name', 'swmtranslate'),
						"desc" => __('In google font page, read how to use font name from 4th section "Integrate the fonts into your CSS", font-family:..', 'swmtranslate'),						
						"id" => $shortname."_google_font_name",
						"std" => "Patua One",						
						"type" => "text");	

	$swm_theme_options[] = array( 
						"name" => __('Font Weight', 'swmtranslate'),
						"desc" => __('Add font weight in number (200,700) or in word (normal, bold).', 'swmtranslate'),						
						"id" => $shortname."_google_font_weight",
						"std" => "normal",					
						"type" => "text");
						
	$swm_theme_options[] = array( 
						"name" => __('Paregraph Fonts', 'swmtranslate'),
						"id" => $shortname."sh3",
						"type" => "sub-heading");	
	
	$swm_theme_options[] = array( 		
						"name" => __('Content Paragraph Text', 'swmtranslate'),	
						"desc" => __('( Default : Size:12px / Color:#606060 )', 'swmtranslate'),						
						"id" => $shortname."_paragraph_font",
						"std" => array('size' => '12px','color' => '#606060'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('Content Headings', 'swmtranslate'),
						"id" => $shortname."sh4",
						"type" => "sub-heading");
	
	$swm_theme_options[] = array( 
						"name" => __('Display Dot Border with Page Title', 'swmtranslate'),
						"desc" => __('Show/Hide dot grey border with page title ', 'swmtranslate'),
						"id" => $shortname."_page_title_dot_border",
						"std" => "1",
						"type" => "checkbox");
	
	$swm_theme_options[] = array( 
						"name" => __('Page Title', 'swmtranslate'),
						"desc" => __('( Default : Size:18px / Color:#ffffff )', 'swmtranslate'),						
						"id" => $shortname."_page_title_font",
						"std" => array('size' => '18px','color' => '#ffffff'),
						"type" => "typography");
	
	$swm_theme_options[] = array( 
						"name" => __('Display Dot Border with Headings', 'swmtranslate'),
						"desc" => __('Show/Hide dot grey border with content, sidebar and footer headings', 'swmtranslate'),
						"id" => $shortname."_headings_dot_border",
						"std" => "1",
						"type" => "checkbox");

	$swm_theme_options[] = array( 
						"name" => __('H1 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:22px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_h1_heading_font",
						"std" => array('size' => '22px','color' => '#313131'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('H2 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:20px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_h2_heading_font",
						"std" => array('size' => '20px','color' => '#313131'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H3 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:18px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_h3_heading_font",
						"std" => array('size' => '18px','color' => '#313131'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H4 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:16px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_h4_heading_font",
						"std" => array('size' => '16px','color' => '#313131'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H5 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:14px / Color:#313131 )', 'swmtranslate'),					
						"id" => $shortname."_h5_heading_font",
						"std" => array('size' => '14px','color' => '#313131'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H6 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:13px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_h6_heading_font",
						"std" => array('size' => '13px','color' => '#313131'),
						"type" => "typography");	

	$swm_theme_options[] = array( 
						"name" => __('Blog Post Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:18px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_blog_post_title_font",
						"std" => array('size' => '18px','color' => '#313131'),
						"type" => "typography");
						
				
	$swm_theme_options[] = array( 
						"name" => __('Sidebar', 'swmtranslate'),
						"id" => $shortname."sh5",
						"type" => "sub-heading");
	
	$swm_theme_options[] = array( 
						"name" => __('Sidebar Widget Title', 'swmtranslate'),
						"desc" => __('( Default : Size:15px / Color:#313131 )', 'swmtranslate'),						
						"id" => $shortname."_sidebar_h2_heading_font",
						"std" => array('size' => '15px','color' => '#313131'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('Footer', 'swmtranslate'),
						"id" => $shortname."sh6",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Large Footer Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:15px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname."_footer_h2_heading_font",
						"std" => array('size' => '16px','color' => '#cccccc'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('Large Footer Text', 'swmtranslate'),
						"desc" => __('( Default : Size:12px / Color:#aaaaaa )', 'swmtranslate'),					
						"id" => $shortname."_large_footer_text",
						"std" => array('size' => '12px','color' => '#aaaaaa'),
						"type" => "typography");				
	
	$swm_theme_options[] = array( 
						"name" => __('Small Footer Text', 'swmtranslate'),
						"desc" => __('( Default : Size:11px / Color:#aaaaaa )', 'swmtranslate'),						
						"id" => $shortname."_small_footer_font",
						"std" => array('size' => '11px','color' => '#aaaaaa'),
						"type" => "typography");						
						
	/* Fonts - Dark Layout*/

	$dark = '_dark';
	
	$swm_theme_options[] = array( 
						"name" => __('Fonts', 'swmtranslate'),
						"id" => $shortname.$dark."_fonts",
						"type" => "heading");

	$swm_theme_options[] = array( 
						"name" => __('Google Font', 'swmtranslate'),
						"id" => $shortname.$dark."sh13",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Import Google Font', 'swmtranslate'),
						"desc" => __('Add google font url as per above example. (Go to http://www.google.com/webfonts > Choose any font and click on "Quick use" link at right side > 3rd section "Add this code to your website" > "Standard" tab > only copy url which starts ..http//... like above example in the box.)', 'swmtranslate'),						
						"id" => $shortname.$dark."_google_font_url",
						"std" => 'http://fonts.googleapis.com/css?family=Patua+One',						
						"type" => "textarea");

	$swm_theme_options[] = array( 
						"name" => __('Font Name', 'swmtranslate'),
						"desc" => __('In google font page, read how to use font name from 4th section "Integrate the fonts into your CSS", font-family:..', 'swmtranslate'),						
						"id" => $shortname.$dark."_google_font_name",
						"std" => "Patua One",						
						"type" => "text");	

	$swm_theme_options[] = array( 
						"name" => __('Font Weight', 'swmtranslate'),
						"desc" => __('Add font weight in number (200,700) or in word (normal, bold).', 'swmtranslate'),						
						"id" => $shortname.$dark."_google_font_weight",
						"std" => "normal",					
						"type" => "text");
						
	$swm_theme_options[] = array( 
						"name" => __('Paregraph Fonts', 'swmtranslate'),
						"id" => $shortname.$dark."sh3",
						"type" => "sub-heading");	
	
	$swm_theme_options[] = array( 		
						"name" => __('Content Paragraph Text', 'swmtranslate'),	
						"desc" => __('( Default : Size:12px / Color:#aaaaaa )', 'swmtranslate'),						
						"id" => $shortname.$dark."_paragraph_font",
						"std" => array('size' => '12px','color' => '#aaaaaa'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('Content Headings', 'swmtranslate'),
						"id" => $shortname.$dark."sh4",
						"type" => "sub-heading");
	
	$swm_theme_options[] = array( 
						"name" => __('Display Dot Border with Page Title', 'swmtranslate'),
						"desc" => __('Show/Hide dot grey border with page title ', 'swmtranslate'),
						"id" => $shortname.$dark."_page_title_dot_border",
						"std" => "1",
						"type" => "checkbox");
	
	$swm_theme_options[] = array( 
						"name" => __('Page Title', 'swmtranslate'),
						"desc" => __('( Default : Size:18px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_page_title_font",
						"std" => array('size' => '18px','color' => '#cccccc'),
						"type" => "typography");
	
	$swm_theme_options[] = array( 
						"name" => __('Display Dot Border with Headings', 'swmtranslate'),
						"desc" => __('Show/Hide dot grey border with content, sidebar and footer headings', 'swmtranslate'),
						"id" => $shortname.$dark."_headings_dot_border",
						"std" => "1",
						"type" => "checkbox");

	$swm_theme_options[] = array( 
						"name" => __('H1 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:22px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_h1_heading_font",
						"std" => array('size' => '22px','color' => '#cccccc'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('H2 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:20px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_h2_heading_font",
						"std" => array('size' => '20px','color' => '#cccccc'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H3 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:18px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_h3_heading_font",
						"std" => array('size' => '18px','color' => '#cccccc'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H4 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:16px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_h4_heading_font",
						"std" => array('size' => '16px','color' => '#cccccc'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H5 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:14px / Color:#cccccc )', 'swmtranslate'),					
						"id" => $shortname.$dark."_h5_heading_font",
						"std" => array('size' => '14px','color' => '#cccccc'),
						"type" => "typography");						
						
	$swm_theme_options[] = array( 
						"name" => __('H6 Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:13px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_h6_heading_font",
						"std" => array('size' => '13px','color' => '#cccccc'),
						"type" => "typography");	

	$swm_theme_options[] = array( 
						"name" => __('Blog Post Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:18px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_blog_post_title_font",
						"std" => array('size' => '18px','color' => '#cccccc'),
						"type" => "typography");
						
				
	$swm_theme_options[] = array( 
						"name" => __('Sidebar', 'swmtranslate'),
						"id" => $shortname.$dark."sh5",
						"type" => "sub-heading");
	
	$swm_theme_options[] = array( 
						"name" => __('Sidebar Widget Title', 'swmtranslate'),
						"desc" => __('( Default : Size:15px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_sidebar_h2_heading_font",
						"std" => array('size' => '15px','color' => '#cccccc'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('Footer', 'swmtranslate'),
						"id" => $shortname.$dark."sh6",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Large Footer Heading', 'swmtranslate'),
						"desc" => __('( Default : Size:15px / Color:#cccccc )', 'swmtranslate'),						
						"id" => $shortname.$dark."_footer_h2_heading_font",
						"std" => array('size' => '16px','color' => '#cccccc'),
						"type" => "typography");
						
	$swm_theme_options[] = array( 
						"name" => __('Large Footer Text', 'swmtranslate'),
						"desc" => __('( Default : Size:12px / Color:#aaaaaa )', 'swmtranslate'),					
						"id" => $shortname.$dark."_large_footer_text",
						"std" => array('size' => '12px','color' => '#aaaaaa'),
						"type" => "typography");				
	
	$swm_theme_options[] = array( 
						"name" => __('Small Footer Text', 'swmtranslate'),
						"desc" => __('( Default : Size:11px / Color:#aaaaaa )', 'swmtranslate'),						
						"id" => $shortname.$dark."_small_footer_font",
						"std" => array('size' => '11px','color' => '#aaaaaa'),
						"type" => "typography");	


	/* Footer */
	
	$swm_theme_options[] = array( 
						"name" => __('Footer', 'swmtranslate'),
						"id" => $shortname."_footer",
						"type" => "heading");
						
	$swm_theme_options[] = array( 
						"name" => __('Large Footer', 'swmtranslate'),
						"id" => $shortname."sh72",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Display Large Footer', 'swmtranslate'),
						"desc" => __('Show/Hide large footer in all pages', 'swmtranslate'),
						"id" => $shortname."_on_off_large_footer",
						"std" => "1",
						"type" => "checkbox");			
						
	$swm_theme_options[] = array( 
						"name" => __('Footer Columns', 'swmtranslate'),
						"desc" => __('Select footer column.', 'swmtranslate'),						
						"id" => $shortname."_footer_column",
						"std" => "three-column",
						"type" => "select",
						"class" => "mini",
						"options" => $footer_column);

	$swm_theme_options[] = array( 
						"name" => __('Small Footer', 'swmtranslate'),
						"id" => $shortname."sh73",
						"type" => "sub-heading");	

	$swm_theme_options[] = array( 
						"name" => __('Display Small Footer', 'swmtranslate'),
						"desc" => __('Show/Hide small footer in all pages', 'swmtranslate'),
						"id" => $shortname."_on_off_small_footer",
						"std" => "1",
						"type" => "checkbox");
	
	$swm_theme_options[] = array( 
						"name" => __('Small Footer Left Content', 'swmtranslate'),
						"desc" => __('Add copyright text in small footer right side.', 'swmtranslate'),						
						"id" => $shortname."_footer_left_content",
						"std" => __('Copyright, Company Name.', 'swmtranslate'),						
						"type" => "textarea");	
	
	/* Portfolio */
	
	$swm_theme_options[] = array( 
						"name" => __('Portfolio', 'swmtranslate'),
						"id" => $shortname."_portfolio",
						"type" => "heading");
						
	$swm_theme_options[] = array( 
						"name" => __('Portfolio Settings', 'swmtranslate'),
						"id" => $shortname."sh14",
						"type" => "sub-heading");	

	$swm_theme_options[] = array( 
						"name" => __('Portfolio Post Single Page Option', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_portfolio_single_options",
						"std" => "portfolio-with-fullwidth",
						"type" => "select",	
						"class" => "mini",
						"options" => $portfolio_single_options);	
	
	$swm_theme_options[] = array( 
						"name" => __('Portfolio Items Parent Page for Breadcrumbs', 'swmtranslate'),
						"desc" => __('Select default parent page for all portfolio items to display in breadcrumbs', 'swmtranslate'),
						"id" => $shortname."_pages_list_portfolio",
						"std" => "",
						"type" => "select",	
						"class" => "mini",
						"options" => $options_pages);


	/* Blog */
	
	$swm_theme_options[] = array( 
						"name" => __('Blog', 'swmtranslate'),
						"id" => $shortname."_blog",
						"type" => "heading");
					
	$swm_theme_options[] = array( 
						"name" => __('Blog Settings', 'swmtranslate'),
						"id" => $shortname."sh17",
						"type" => "sub-heading");
	
	$swm_theme_options[] = array( 
						"name" => __('Display Excerpt', 'swmtranslate'),
						"desc" => __('Show/Hide post summery text in post listing.', 'swmtranslate'),
						"id" => $shortname."_show_excerpt",
						"std" => "1",
						"type" => "checkbox");	

	$swm_theme_options[] = array( 
						"name" => __('Excerpt Length', 'swmtranslate'),
						"desc" => __('Enter post summery text character length (e.g. 200)', 'swmtranslate'),
						"id" => $shortname."_excerpt_length",
						"std" => "250",
						"class" => "mini",
						"type" => "text");	
	
	$swm_theme_options[] = array( 
						"name" => __('Display Post Date', 'swmtranslate'),
						"desc" => __('Show/Hide post date beside title.', 'swmtranslate'),
						"id" => $shortname."_post_date",
						"std" => "1",
						"type" => "checkbox");

	$swm_theme_options[] = array( 
						"name" => __('Display Post Year', 'swmtranslate'),
						"desc" => __('Show/Hide post year.', 'swmtranslate'),
						"id" => $shortname."_post_year",
						"std" => "0",
						"type" => "checkbox");	

	$swm_theme_options[] = array( 
						"name" => __('Display Post Comments Count', 'swmtranslate'),
						"desc" => __('Show/Hide comments number located below post date.', 'swmtranslate'),
						"id" => $shortname."_post_comments_count",
						"std" => "1",
						"type" => "checkbox");																

	$swm_theme_options[] = array( 
						"name" => __('Display Post Author', 'swmtranslate'),
						"desc" => __('Show/Hide post author\'s name located below post content.', 'swmtranslate'),
						"id" => $shortname."_post_author",
						"std" => "1",
						"type" => "checkbox");					

	$swm_theme_options[] = array( 
						"name" => __('Display Post Categories', 'swmtranslate'),
						"desc" => __('Show/Hide post categories  located below post content.', 'swmtranslate'),
						"id" => $shortname."_post_categories",
						"std" => "1",
						"type" => "checkbox");	
	
	$swm_theme_options[] = array( 
						"name" => __('Display Post Tags', 'swmtranslate'),
						"desc" => __('Show/Hide post tags located below post content.', 'swmtranslate'),
						"id" => $shortname."_post_tags",
						"std" => "0",
						"type" => "checkbox");		
					
	$swm_theme_options[] = array( 
						"name" => __('Display Read More Button', 'swmtranslate'),
						"desc" => __('Show/Hide "Read more" button from post listing page.', 'swmtranslate'),
						"id" => $shortname."_post_button",
						"std" => "1",
						"type" => "checkbox");

	$swm_theme_options[] = array( 
						"name" => __('Read More Button Text', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_post_button_text",
						"std" => __('Read more', 'swmtranslate'),
						"class" => "mini",
						"type" => "text");					

	$swm_theme_options[] = array( 
						"name" => __('How Many Blog Posts per Page?', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_blog_posts_per_page",
						"std" => "5",
						"class" => "mini",
						"type" => "text");				

	$swm_theme_options[] = array( 
						"name" => __('Exclude Categories from Blog', 'swmtranslate'),
						"desc" => __('Add category IDs, separated by commas (e.g. 1,23,56).', 'swmtranslate'),						
						"id" => $shortname."_blog_exclude_categories",
						"std" => "",						
						"type" => "text");			

					
	/* Blog Single */
	
	$swm_theme_options[] = array( 
						"name" => __('Blog Single', 'swmtranslate'),
						"id" => $shortname."sh18",
						"type" => "sub-heading");

	$swm_theme_options[] = array( 
						"name" => __('Display Share This Post', 'swmtranslate'),
						"desc" => __('Show/Hide "Share this post" option in post date section - below post content.', 'swmtranslate'),
						"id" => $shortname."_post_single_share",
						"std" => "1",
						"type" => "checkbox");	
	
	$swm_theme_options[] = array( 
						"name" => __('Display About Author Info', 'swmtranslate'),
						"desc" => __('Show/Hide About author box. (You can set author\'s bio from - Wordpress Admin > Users > Your Profile > About Yourself Box)', 'swmtranslate'),
						"id" => $shortname."_about_author_box",
						"std" => "1",
						"type" => "checkbox");	
						
	$swm_theme_options[] = array( 
						"name" => __('Display Post Comments', 'swmtranslate'),
						"desc" => __('Show/Hide post comments.', 'swmtranslate'),
						"id" => $shortname."_post_comments",
						"std" => "1",
						"type" => "checkbox");
	
						
	/* Error 404 */
	
	$swm_theme_options[] = array( 
						"name" => __('Error 404', 'swmtranslate'),
						"id" => $shortname."_error_page",
						"type" => "heading");
						
	$swm_theme_options[] = array( 
						"name" => __('Error 404 page Settings', 'swmtranslate'),
						"id" => $shortname."sh28",
						"type" => "sub-heading");
	
	$swm_theme_options[] = array( 
						"name" => __('Error 404 Title Text', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_error_page_title",
						"std" => "Error 404",					
						"type" => "text");
						
	$swm_theme_options[] = array( 
						"name" => __('Error 404 Message', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_error_page_content",
						"std" => '<h1>Oops...</h1>
									
								<h4>The page you were looking for appears to have been moved, deleted or does not exist.</h4>
								<p>You can visit our other pages:</p>									
								<ul>
									<li><a href="#">Home</a></li>
									<li><a href="#">About Us</a></li>								
									<li><a href="#">Services</a></li>
									<li><a href="#">Portfolio</a></li>
									<li><a href="#">Contact Us</a></li>
								</ul>',										
						"type" => "textarea");	
						
	$swm_theme_options[] = array( 
						"name" => __('Error 404 Image', 'swmtranslate'),
						"desc" => __('Sample 404 Error image size - 451px x 257px', 'swmtranslate'),						
						"id" => $shortname."_error_page_image",
						"type" => "upload");

	/* Social Media */
	
	$swm_theme_options[] = array( 
						"name" => __('Social Media', 'swmtranslate'),
						"id" => $shortname."_social_media",
						"type" => "heading");
						
	$swm_theme_options[] = array( 	
						"name" => __('Social Media Settings', 'swmtranslate'),
						"id" => $shortname."sh30",
						"type" => "sub-heading");
						
	$swm_theme_options[] = array( 
						"name" => '',
						"desc" => __('Enter Full URL of social media websites ( e.g. http://www.twitter.com/softwebmedia )', 'swmtranslate'),
						"id" => $shortname."_social_intro_text",
						"std" => "",				
						"class" => "social_intro_text",
						"type" => "info");					
						
	$swm_theme_options[] = array( 
						"name" => __('Twitter', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_twitter_url",
						"std" => "",
						"type" => "text");

	$swm_theme_options[] = array( 
						"name" => __('Facebook', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_facebook_url",
						"std" => "",
						"type" => "text");					

	$swm_theme_options[] = array( 
						"name" => __('You Tube', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_youtube_url",
						"std" => "",
						"type" => "text");
					
	$swm_theme_options[] = array( 
						"name" => __('Flickr', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_flickr_url",
						"std" => "",
						"type" => "text");

	$swm_theme_options[] = array( 
						"name" => __('Delicious', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_delicious_url",
						"std" => "",
						"type" => "text");
					
	$swm_theme_options[] = array( 
						"name" => __('Digg', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_digg_url",
						"std" => "",
						"type" => "text");
					
	$swm_theme_options[] = array( 
						"name" => __('Vimeo', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_vimeo_url",
						"std" => "",
						"type" => "text");					
					
	$swm_theme_options[] = array( 
						"name" => __('Blogger', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_blogger_url",
						"std" => "",
						"type" => "text");					
					
	$swm_theme_options[] = array( 
						"name" => __('Linkedin', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_linkedin_url",
						"std" => "",
						"type" => "text");	

	$swm_theme_options[] = array( 
						"name" => __('StumbleUpon', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_stumbleupon_url",
						"std" => "",
						"type" => "text");	

	$swm_theme_options[] = array( 
						"name" => __('Technorati', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_technorati_url",
						"std" => "",
						"type" => "text");										
					
	$swm_theme_options[] = array( 
						"name" => __('RSS', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_rss_url",
						"std" => "",
						"type" => "text");	

							
	$swm_theme_options[] = array( 
						"name" => __('Open Website in New Window', 'swmtranslate'),
						"desc" => __('Set ON to open in new window', 'swmtranslate'),
						"id" => $shortname."_open_in_new_window",
						"std" => "1",
						"type" => "checkbox");
	
	/* Custom CSS/Javascript */
	
	$swm_theme_options[] = array( 
						"name" => __('Custom CSS/Javascript', 'swmtranslate'),
						"id" => $shortname."_custom_css_js",
						"type" => "heading");

	$swm_theme_options[] = array( 
						"name" => __('Add CSS', 'swmtranslate'),
						"id" => $shortname."sh31",
						"type" => "sub-heading");
						
	$swm_theme_options[] = array( 
						"name" => __('Add Custom CSS code', 'swmtranslate'),
						"desc" => __('Add your custom css style ( e.g. .sample-style { color:#ccc; } )', 'swmtranslate'),
						"id" => $shortname."_custom_css",
						"std" => "",				
						"class" => "large-textarea",
						"type" => "textarea");						
						
	$swm_theme_options[] = array( 
						"name" => __('Add Javascripts', 'swmtranslate'),
						"id" => $shortname."sh32",
						"type" => "sub-heading");
						
	$swm_theme_options[] = array( 
						"name" => __('Add Custom Javascript code', 'swmtranslate'),
						"desc" => '',
						"id" => $shortname."_custom_js",
						"std" => "",				
						"class" => "large-textarea",
						"type" => "textarea");				
	return $swm_theme_options;
}